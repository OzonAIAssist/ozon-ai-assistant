(function(){
 'use strict';
 var errors=[],ready=false,timer;
 function status(message){var el=document.getElementById('hogar-startup-message');if(el)el.textContent=message}
 function record(e){var name=String(e&&e.name||e&&e.message||'JavaScript').match(/[A-Za-z]+Error/);errors.push(name?name[0]:'JavaScript');if(errors.length>3)errors.shift();if(!ready)status('Не удалось завершить запуск. Можно повторить загрузку; данные сохранятся. Версия mobile-p0.')}
 window.addEventListener('error',record);
 window.addEventListener('unhandledrejection',function(e){record(e.reason)});
 function check(){
  ready=!!(document.querySelector('.bottom-nav')&&document.getElementById('h44')&&document.querySelector('#tab-home .hd-root'));
  if(ready){clearTimeout(timer);document.documentElement.setAttribute('data-hogar-boot','ready');var el=document.getElementById('hogar-startup');if(el)el.hidden=true}
  else status('Интерфейс не запустился. '+(errors.join('; ')||'Нет готового интерфейса')+'. Повторите загрузку. Данные на устройстве сохранены. Версия mobile-p0.');
 }
 // Interface readiness is independent of authentication and remote API responses.
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(check,0)},{once:true});else setTimeout(check,0);
 window.addEventListener('pageshow',function(e){if(e.persisted)check()});
 timer=setTimeout(function(){if(!ready){document.documentElement.setAttribute('data-hogar-boot','error');status('Запуск не завершился за 15 секунд. Повторите загрузку. Локальные данные не удаляются. Версия mobile-p0.')}},15000);
})();
