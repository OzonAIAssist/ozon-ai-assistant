(function(){
 'use strict';
 const api='https://ozon-ai-assistant-api.onrender.com',authKey='hogar_device_access_v1',legacy='hogar_session_access_v44',prefix='hogar_http_cache_v1:';
 const nativeFetch=window.fetch.bind(window),pending=new Map(),retry=new Map();let manualUntil=0;
 document.addEventListener('click',e=>{if(e.isTrusted&&e.target.closest?.('#v10sync,#h44refresh,#h50refresh,.h90-refresh-ad,[data-refresh]'))manualUntil=Date.now()+1500},true);
 const read=k=>{try{return JSON.parse(localStorage.getItem(k)||'null')}catch(_){return null}};
 // Authentication reads must not fail as a group when one storage is unavailable.
 function access(){let v=document.getElementById('v10token')?.value.trim()||'';if(!v)try{v=sessionStorage.getItem(legacy)||''}catch(_){}if(!v)try{v=localStorage.getItem(authKey)||''}catch(_){}if(v){try{if(localStorage.getItem(authKey)!==v)localStorage.setItem(authKey,v)}catch(_){}try{if(sessionStorage.getItem(legacy)!==v)sessionStorage.setItem(legacy,v)}catch(_){}}return v}
 // Bound both receipt of headers and the response body. Some mobile connections
 // return headers but never finish the body; a fetch-only timeout misses this.
 async function request(input,options={}){
  const controller=typeof AbortController==='function'?new AbortController():null,signal=options.signal||(input instanceof Request?input.signal:undefined);
  let timer,abort;const timeout=new Promise((_,reject)=>{abort=()=>{controller?.abort();const e=Error(signal?.aborted?'Запрос отменён.':'Сервер не ответил за 30 секунд. Повторите загрузку.');e.name=signal?.aborted?'AbortError':'TimeoutError';reject(e)};timer=setTimeout(abort,30000);if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true})});
  try{return await Promise.race([timeout,(async()=>{const r=await nativeFetch(input,{...options,...(controller?{signal:controller.signal}:{})});if(r.status===204||r.status===205||r.status===304)return r;const body=await r.arrayBuffer();return new Response(body,{status:r.status,statusText:r.statusText,headers:r.headers})})()])}
  finally{clearTimeout(timer);signal?.removeEventListener('abort',abort)}
 }
 function usable(url,entry){if(!entry||!entry.body||!Number.isFinite(entry.at))return false;const d=entry.body;return url.pathname==='/api/products'?Array.isArray(d.items):url.pathname==='/api/orders'?Array.isArray(d.orders):url.pathname==='/api/ads/campaigns'?Array.isArray(d.campaigns):url.pathname==='/api/ads/statistics'?Array.isArray(d.rows):url.pathname==='/api/orders/finance'?Array.isArray(d.operations):typeof d==='object'&&!Array.isArray(d)}
 const allowed=new Set(['/api/products','/api/orders','/api/orders/finance','/api/ads/campaigns','/api/ads/statistics','/api/dashboard/balance','/api/dashboard/stocks']);
 function save(k,value){try{localStorage.setItem(k,JSON.stringify(value))}catch(_){/* Existing module caches remain usable if device storage is full. */}}
 function response(entry){return new Response(JSON.stringify(entry.body),{status:200,headers:{'Content-Type':'application/json','X-Hogar-Cache':'device'}})}
 function announce(url){window.dispatchEvent(new CustomEvent('hogar:data-cache-updated',{detail:{path:url.pathname}}))}
 async function update(url,options,key){
  if(pending.has(key))return (await pending.get(key)).clone();
  const task=(async()=>{const r=await request(url.href,options);if(r.ok){const body=await r.clone().json();const entry={at:Date.now(),body};if(!usable(url,entry))throw Error('Сервер вернул некорректные данные. Сохранённые данные не изменены.');save(key,entry);retry.delete(key);announce(url)}else if(r.status===429){retry.set(key,Date.now()+Math.max(900,Number(r.headers.get('Retry-After'))||0)*1000)}else retry.set(key,Date.now()+60000);return r})();
  pending.set(key,task);try{return (await task).clone()}finally{pending.delete(key)}
 }
 window.fetch=async function(input,options={}){
  const url=new URL(typeof input==='string'?input:input.url,location.href);if(url.origin!==api)return nativeFetch(input,options);
  const headers=new Headers(options.headers||(input instanceof Request?input.headers:undefined));const token=access();if(token&&!headers.has('Authorization'))headers.set('Authorization','Bearer '+token);
  const opts={...options,headers},method=String(options.method||(input instanceof Request?input.method:'GET')).toUpperCase();
  if(method!=='GET'||!allowed.has(url.pathname)||!token)return request(input,opts);
  const key=prefix+url.pathname+url.search,entry=read(key),ttl=url.pathname==='/api/products'?15*60000:5*60000;
  if(usable(url,entry)&&Date.now()>=manualUntil){
   if(Date.now()-entry.at>=ttl&&Date.now()>=(retry.get(key)||0))update(url,opts,key).catch(()=>retry.set(key,Date.now()+60000));
   return response(entry);
  }
  return update(url,opts,key);
 };
 function hydrate(){const t=access(),input=document.getElementById('v10token');if(input&&t){input.value=t;input.hidden=true;const label=document.querySelector('label[for=v10token]');if(label)label.hidden=true}if(t)document.documentElement.dataset.deviceConnected='true'}
 access();document.addEventListener('DOMContentLoaded',()=>{hydrate();document.getElementById('v10token')?.addEventListener('change',hydrate);setTimeout(cycle,1500)});
 // Timers stop when the app is hidden/offline; no paid price scans or ad writes.
 let lastCycle=0;
 function cycle(){if(document.hidden||navigator.onLine===false||!access()||Date.now()-lastCycle<60000)return;lastCycle=Date.now();window.dispatchEvent(new Event('hogar:background-refresh'))}
 setInterval(cycle,5*60000);document.addEventListener('visibilitychange',cycle);window.addEventListener('online',cycle);
 window.HogarDeviceAccess=access;
})();
