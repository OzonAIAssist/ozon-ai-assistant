(function(){
 'use strict';
 var errors=[],ready=false;
 function status(message){var el=document.getElementById('hogar-startup-message');if(el)el.textContent=message}
 window.addEventListener('error',function(e){var type=String(e.message||'').match(/(?:Uncaught )?([A-Za-z]+Error)/);errors.push((type?type[1]:'JavaScript')+(e.lineno?' · строка '+e.lineno:''));if(errors.length>3)errors.shift();if(!ready)status('Не удалось завершить запуск. '+errors.join('; ')+'. Версия 20261028r5.')});
 document.addEventListener('DOMContentLoaded',function(){setTimeout(function(){ready=!!(document.querySelector('.bottom-nav')&&document.getElementById('h44')&&document.querySelector('#tab-home .hd-root'));if(ready){document.documentElement.setAttribute('data-hogar-boot','ready');var el=document.getElementById('hogar-startup');if(el)el.hidden=true}else status('Интерфейс не запустился. '+(errors.join('; ')||'Нет готового интерфейса')+'. Версия 20261028r5.')},0)});
 setTimeout(function(){if(!ready&&!errors.length)status('Загрузка занимает больше обычного. Можно повторить открытие страницы. Версия 20261028r5.')},15000);
})();
