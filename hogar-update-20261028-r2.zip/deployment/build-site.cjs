'use strict';
const fs=require('node:fs'),path=require('node:path');
function publicOrigin(raw){const u=new URL(raw);if(u.protocol!=='https:'||u.origin!==raw||u.username||u.password||u.hostname==='localhost')throw Error('PUBLIC_ORIGIN must be an exact HTTPS origin');return u.origin}
function bundle(html,read){
 const deferred=[];
 html=html.replace(/<link\b[^>]*rel="stylesheet"[^>]*href="([a-zA-Z0-9_-]+\.css)(?:\?[^"]*)?"[^>]*>/g,(_,file)=>'<style data-bundled="'+file+'">'+read(file).replace(/<\/style/gi,'<\\/style')+'</style>');
 html=html.replace(/<script\b([^>]*?)src="([a-zA-Z0-9_-]+\.js)(?:\?[^"]*)?"([^>]*)>\s*<\/script>/g,(_,before,file,after)=>{const tag='<script data-bundled="'+file+'">'+read(file).replace(/<\/script/gi,'<\\/script')+'</script>';if(/\bdefer\b/.test(before+after)){deferred.push(tag);return ''}return tag});
 return html.replace('<head>','<head><meta name="hogar-release" content="20261028r2">').replace('</body>',deferred.join('')+'</body>');
}
function build(source,output,origin){origin=publicOrigin(origin);const html=fs.readFileSync(path.join(source,'index.html'),'utf8'),files=new Set(['index.html']);for(const match of html.matchAll(/(?:src|href)="([a-zA-Z0-9_-]+\.(?:js|css))(?:\?[^\"]*)?"/g))files.add(match[1]);fs.mkdirSync(output,{recursive:true});for(const file of files){let text=fs.readFileSync(path.join(source,file),'utf8').replaceAll('https://ozon-ai-assistant-api.onrender.com',origin);if(file==='index.html')text=bundle(text,name=>fs.readFileSync(path.join(source,name),'utf8').replaceAll('https://ozon-ai-assistant-api.onrender.com',origin));fs.writeFileSync(path.join(output,file),text,{mode:0o644})}return [...files]}
if(require.main===module){const source=path.resolve(__dirname,'..');console.log('Prepared '+build(source,process.env.SITE_OUTPUT||path.join(source,'public-site'),process.env.PUBLIC_ORIGIN).length+' public assets')}
module.exports={build,publicOrigin,bundle};
