'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
test('HTTPS edge uses TCP protocols and expires previously advertised HTTP/3',()=>{
 const config=fs.readFileSync(__dirname+'/deployment/Caddyfile','utf8');
 assert.match(config,/servers\s*\{\s*(?:#[^\n]*\n\s*)*protocols h1 h2\s*\}/);
 assert.match(config,/header Alt-Svc "clear"/);
 assert.match(config,/reverse_proxy app:8080/);
 assert(!/auto_https off|tls_insecure_skip_verify/.test(config));
});
