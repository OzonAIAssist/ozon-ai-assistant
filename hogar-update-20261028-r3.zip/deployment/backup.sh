#!/usr/bin/env bash
set -euo pipefail
umask 077
cd -- "$(dirname -- "$0")"
backup_target="${1:?Specify an existing private backup directory}"
test -d "$backup_target"
backup_path="$backup_target/hogar-$(date -u +%Y%m%dT%H%M%SZ)-$$.dump"
docker compose exec -T database pg_dump -U hogar -d hogar -Fc > "$backup_path.partial"
test -s "$backup_path.partial"
mv -- "$backup_path.partial" "$backup_path"
printf 'Database backup completed. Copy it to independent encrypted storage.\n'
