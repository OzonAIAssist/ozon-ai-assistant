'use strict';
const crypto=require('node:crypto');
const {createStore}=require('../cloud-store');
function cloudRoute({connectionString,origin,upstream,accessToken,account}){
 const store=createStore({connectionString,account}),authCache=new Map();
 async function allowed(token){if(!token||token.length>4096)return false;if(accessToken){const a=Buffer.from(token),b=Buffer.from(accessToken);return a.length===b.length&&crypto.timingSafeEqual(a,b)}if(!upstream)return false;const hash=crypto.createHash('sha256').update(token).digest('hex');if((authCache.get(hash)||0)>Date.now())return true;const r=await fetch(upstream+'/api/products',{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(20000),redirect:'error'});await r.body?.cancel();if(r.ok){if(authCache.size>100)authCache.clear();authCache.set(hash,Date.now()+300000);return true}return false}
 return async(req,res)=>{const cors={'Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type','Cache-Control':'no-store','Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff'};const send=(status,body)=>{res.writeHead(status,cors);res.end(JSON.stringify(body))};if(req.headers.origin&&req.headers.origin!==origin)return send(403,{error:'ORIGIN_NOT_ALLOWED'});if(req.method==='OPTIONS'){res.writeHead(204,cors);return res.end()}if(!['GET','POST'].includes(req.method))return send(405,{error:'METHOD_NOT_ALLOWED'});
 try{const token=(req.headers.authorization||'').replace(/^Bearer /,'');if(!await allowed(token))return send(401,{error:'UNAUTHORIZED'});if(req.method==='GET')return send(200,await store.state());let raw='';for await(const part of req){raw+=part.toString('utf8');if(Buffer.byteLength(raw)>2000000)return send(413,{error:'BODY_TOO_LARGE'})}let input;try{input=JSON.parse(raw)}catch(_){return send(400,{error:'INVALID_JSON'})}const result=await store.write(input.changes);send(result.status,result)}catch(_){send(503,{error:'CLOUD_UNAVAILABLE'})}
 };
}
module.exports={cloudRoute};
