'use strict';
const fs=require('node:fs'),path=require('node:path');
function publicOrigin(raw){const u=new URL(raw);if(u.protocol!=='https:'||u.origin!==raw||u.username||u.password||u.hostname==='localhost')throw Error('PUBLIC_ORIGIN must be an exact HTTPS origin');return u.origin}
function build(source,output,origin){origin=publicOrigin(origin);const html=fs.readFileSync(path.join(source,'index.html'),'utf8'),files=new Set(['index.html']);for(const match of html.matchAll(/(?:src|href)="([a-zA-Z0-9_-]+\.(?:js|css))(?:\?[^\"]*)?"/g))files.add(match[1]);fs.mkdirSync(output,{recursive:true});for(const file of files){const text=fs.readFileSync(path.join(source,file),'utf8').replaceAll('https://ozon-ai-assistant-api.onrender.com',origin);fs.writeFileSync(path.join(output,file),text,{mode:0o644})}return [...files]}
if(require.main===module){const source=path.resolve(__dirname,'..');console.log('Prepared '+build(source,process.env.SITE_OUTPUT||path.join(source,'public-site'),process.env.PUBLIC_ORIGIN).length+' public assets')}
module.exports={build,publicOrigin};
